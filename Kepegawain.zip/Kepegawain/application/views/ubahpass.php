<form action="" method="post">
	<div class="form-group">
		<label>Password Lama</label>
		<input type="text" name="pass_lama" class="form-control" >
	</div>
	<div class="form-group">
		<label>Password Baru</label>
		<input type="text" name="pass_baru" class="form-control" >
	</div>
	<div class="form-group">
		<button class="btn btn-primary" type="submit">Ubah</button>
	</div>
</form>