<center>
<img src="gambar/unikom.png" style="width: 400px; height: 400px;" />
    <div class="welcome-text">
		<h2></h2>    </div>
    <table>
			<tr>
				
				<td>
					<center>
						<h3>PT. Unikom</h3>
					<h5>Jl. Dipati Ukur No.112-116, Lebakgede, Kecamatan Coblong, Kota Bandung, Jawa Barat 40132</h5>
					</center>
				</td>
			</tr>
		</table>
    </center>